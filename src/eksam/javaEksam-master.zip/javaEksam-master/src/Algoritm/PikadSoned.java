package Algoritm;

import java.util.Arrays;

/**
 * Antud on massiiv. Mitu sõne on massiivis keskmisest pikemad?
 */
public class PikadSoned {

    String[] naide = {"kaalikas", "joonas", "maakera", "homeros", "mandel"}; // vastus on 3

}
